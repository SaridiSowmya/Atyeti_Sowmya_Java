package com.atyeti.main;

import com.atyeti.databaseconnection.DataBaseConn;
import com.atyeti.filehandling.LogFileReader;

import java.io.FileNotFoundException;
import java.sql.*;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {

        String directoryPath="C:\\Users\\SowmyaSaridi\\OneDrive - Atyeti Inc\\Desktop\\Atyeti_Sowmya_Java\\pairprogramming\\src\\com\\atyeti\\logfiles";
        LogFileReader.readLogs(directoryPath);
        DataBaseConn.database();


    }
}
