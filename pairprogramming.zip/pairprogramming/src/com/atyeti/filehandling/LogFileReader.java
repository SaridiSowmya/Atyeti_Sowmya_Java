package com.atyeti.filehandling;

import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public class LogFileReader {

    private static final Logger logger = Logger.getLogger(LogFileReader.class.getName());

    public static int errorCount = 0;
    public static int warnCount = 0;
    public static int infoCount = 0;

    static String outputFile = "C:\\Users\\SowmyaSaridi\\OneDrive - Atyeti Inc\\Desktop\\Atyeti_Sowmya_Java\\pairprogramming\\src\\com\\atyeti\\duplicatefiles\\logOutputWriter";

    public static void readLogs(String directoryPath) throws FileNotFoundException {

        File file = new File(directoryPath);
        if (!file.exists() || !file.isDirectory()) {
            logger.warning("Directory does not exist: " + directoryPath);
            return;
        }

        File[] files = file.listFiles((d, name) -> name.endsWith(".log")); // filter only .log files
        if (files == null || files.length == 0) {
            logger.warning("No log files found in directory: " + directoryPath);
            return;
        }
        for (File file1 : files) {
            logger.info("Reading file: " + file.getName());
            try (BufferedReader bufferedReader = new BufferedReader(new FileReader(file1));
                 BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(outputFile))) {
                String line = "";
                while ((line = bufferedReader.readLine()) != null) {
                    bufferedWriter.write(line);
                    bufferedWriter.newLine();
                    String[] split = line.split(" - ");
                    if (split.length < 3 || split[0].isEmpty() || split[1].isEmpty() || split[2].isEmpty()) {
                        logger.warning("skipping lines due to missing fields" + line);
                        continue;
                    }

                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

        File folder1 = new File(directoryPath);
        File[] files1 = folder1.listFiles();
        if (files1 != null) {
            for (File file1 : files1) {
                if (file1.isFile()) {
                    try (BufferedReader br = new BufferedReader(new FileReader(file1))) {
                        String line;
                        while ((line = br.readLine()) != null) {
                            if (line.contains(" ERROR ")) errorCount++;
                            if (line.contains(" WARNING ")) warnCount++;
                            if (line.contains(" INFO ")) infoCount++;
                        }
                    } catch (IOException e) {
                        logger.severe("Error reading file: " + file.getName());

                    }

                }
            }
        }
    }
}
